#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>

enum Color {PIQUE = 1, CARREAU, TREFLE, COEUR};
enum Value {AS = 1, DEUX, TROIS, QUATRE, CINQ, SIX, SEPT, HUIT, NEUF, DIX, VALET, DAME, ROI};

typedef struct
{
    enum Color color;	// 1 = pique ; 2 = carreau ; 3 = trèfle ; 4 = coeur
    enum Value val;		// de 1 (pour as) à 14 (pour roi)
}Card;

typedef struct
{
    int id;
    int budget;
    Carte main[2];

}Player;

int higherHand(Player* player_list, Card* croupier_hand)
{
	Player winner = NULL;


	return winner.id;
}

bool isPair(Card* player_card, Card* croupier_hand)
{
	int i, j;
	if(player_card[0].val == player_card[1].val)
		return true;
	for(i=0 ; i<2 ; i++)
	{
		for(j=0 ; j<5 ; j++)
		{
			if(player_card[i].val == croupier_hand[j].val)
			{
				return true;
			}
		}
	}
	return false;
}

bool isDoublePair(Card* player_card, Card* croupier_hand)
{
	int i, j;
	int compteur = 0;
	if(player_card[0].val == player_card[1].val)
		compteur++;
	for(i=0 ; i<2 ; i++)
	{
		for(j=0 ; j<5 ; j++)
		{
			if(player_card[i].val == croupier_hand[j].val)
			{
				compteur++;
			}
		}
	}
	if(compteur > 2)
		return true;
	else
		return false;
}

bool isFull(Card* player_card, Card* croupier_hand)
{
	int i, j;
	int compteur = 0;
	for(i=0 ; i<2 ; i++)
	{
		for(j=0 ; j<5 ; j++)
		{
			if(player_card[i].val == croupier_hand[j].val)
			{
				compteur++;
			}
		}
	}
	if(compteur > 2)
		return true;
	else
		return false;
}

bool isFlush(Card* player_card, Card* croupier_hand)
{
	int i, j;
	int compteur = 0;
	for(i=0 ; i<2 ; i++)
	{
		for(j=0 ; j<5 ; j++)
		{
			if(player_card[i].val == croupier_hand[j].val)
			{
				compteur++;
			}
		}
	}
	if(compteur > 2)
		return true;
	else
		return false;
}


void printCard(Card)
{

}
Carte* c = malloc(sizeof(Carte) * 4);
c[0].val = 0;
c[0].
